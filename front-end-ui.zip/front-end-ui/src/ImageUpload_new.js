import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';

function ImageUpload() {
  const [imageURL, setImageURL] = useState('');
  const [replacementURL, setReplacementURL] = useState(null);
  const [classification, setClassification] = useState(null);
  const [progress, setProgress] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [progressclassify, setProgressclassify] = useState(0);
  const [classify, setClassify] = useState(false);

  const onImageChange = async event => {
    if (event.target.files && event.target.files[0]) {
      const formData = new FormData();
      formData.append('image', event.target.files[0]);
      setImageURL(URL.createObjectURL(event.target.files[0]));
      setImageURL(URL.createObjectURL(event.target.files[0]));
      setProgress(0);

      fetch('http://localhost:3100/upload', {
        method: 'POST',
        body: formData,
      })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            console.log('Upload and script execution successful');
            setReplacementURL(data.url);
            console.log(data.url);
            console.log(data.jsonUrl);
            fetch(data.jsonUrl)
              .then(response => response.json())
              .then(data => {
              //console.log(data.Flag); // Print the extracted value
              setClassification(data.Flag);
              })
  .catch(error => {
    console.log('Error:', error);
  });
          } else {
            console.log('Upload failed or script execution failed');
          }
        });
    }
  };

  useEffect(() => {
    if (imageLoaded && progress < 100) {
      const timer = setInterval(() => {
        setProgress((oldProgress) => {
          if (oldProgress === 100) {
            clearInterval(timer);
            // setStartProgressClassify(true);
            // console.log('startProgressClassify1: ', startProgressClassify);
          }
          const diff = Math.random() * 6.3;
          return Math.min(oldProgress + diff, 100);
        });
      }, 100);
    
      return () => {
        clearInterval(timer);
      };
    }
    // if (progress >= 90) {
    //   setClassify(true);
    //   console.log('startProgressClassify2: ', Classify);
    // }
  }, [imageLoaded, progress]);

  useEffect(() => {
    if (progress === 100) {
      setClassify(true);
      console.log('startProgressClassify2: ', classify);
    }
  }, [progress]);

  useEffect(() => {
    if (classify) {
      console.log('Classify changed to: ', classify);
    }
  }, [classify]);

  // useEffect(() => {
  //   if (classify && progressclassify < 100) {
  //     const timer = setInterval(() => {
  //       setProgressclassify((oldProgress) => {
  //         if (oldProgress === 100) {
  //           clearInterval(timer);
  //         }
  //         const diff = Math.random() * 6.9;
  //         return Math.min(oldProgress + diff, 100);
  //       });
  //     }, 100);
  
  //     return () => {
  //       clearInterval(timer);
  //     };
  //   }
  // }, [classify, progressclassify]);
  useEffect(() => {
    if (classify && progressclassify < 100) {
      const timer = setInterval(() => {
        setProgressclassify((oldProgress) => {
          if (oldProgress >= 100) {
            clearInterval(timer);
          }
          // The higher the value of "power", the slower the initial progress
          const power = 0.95;
          const diff = (Math.pow(oldProgress / 100, power) * 100) - oldProgress;
          return Math.min(oldProgress + diff + 2, 100);
        });
      }, 100);
  
      return () => {
        clearInterval(timer);
      };
    }
  }, [classify, progressclassify]);
  
  
  

  return (
    <Box sx={{ textAlign: 'center' }}>
      <div>
        <Typography variant="h4" component="h2" gutterBottom>
            Mammogram Segmentation
        </Typography>
        <Typography variant="subtitle1" gutterBottom>
            Please upload a mammogram image below
        </Typography>
        <Button
          variant="contained"
          component="label"
        >
            Upload Image
            <input
              type="file"
              hidden
              accept="image/*"
              onChange={onImageChange}
            />
        </Button>
        <Box sx={{ mt: 5, marginLeft: '200px' }}>
          <Box style={{position: 'relative', width: '250px'}}>
            {imageURL && (
              <img
                src={imageURL}
                onLoad={() => setImageLoaded(true)}
                alt="Uploaded Mammogram"
                style={{  width: "250px", position: 'absolute', left: 20, top: 0, zIndex: 10 }}
              />
            )}

            {replacementURL && (
              <img
                src={replacementURL}
                alt="Uploaded Mammogram"
                style={{ position: "absolute", width: '250px', zIndex: 100, left: 20, top: 0, opacity: 0.5 }}
              />
            )}
          </Box>

        </Box>
        {imageLoaded &&
          <Box sx={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 40 }}>
            <LinearProgress variant="determinate" value={progress} style={{ width: '250px' }} />
            <Typography variant="subtitle1" component="subtitle1" gutterBottom>
              Model Inferencing
            </Typography>
          </Box>
        }
        {classify &&
          <Box sx={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 3}}>
              <LinearProgress variant="determinate" value={progressclassify} style={{ width: '250px' }} />
              <Typography variant="subtitle1" component="div" gutterBottom>
                Patch Diagnosis
              </Typography>
          </Box>}
      </div>
    </Box>

);
}

export default ImageUpload;