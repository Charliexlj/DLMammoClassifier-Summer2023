import React from 'react'
import ImageUpload from './ImageUpload_new'
import Title from './Title'
// import PythonExecutor from './python_execute'
import ImageSegment from './ImageSegment'
import './grid.css'

export default function Grid () {
  
    return (
      <div className="container">
        <div class='title'><Title/></div>
        <div><ImageUpload/> </div>
        <div><ImageSegment/></div>
        {/* <div><PythonExecutor/> </div> */}
      </div>
    )
  }