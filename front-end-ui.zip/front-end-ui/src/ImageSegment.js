import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import AddTaskIcon from '@mui/icons-material/AddTask';
import AllOutIcon from '@mui/icons-material/AllOut';
import BorderClearIcon from '@mui/icons-material/BorderClear';
import BlurOnIcon from '@mui/icons-material/BlurOn';
import CoronavirusIcon from '@mui/icons-material/Coronavirus';
import BorderOuterIcon from '@mui/icons-material/BorderOuter';
import ScatterPlotIcon from '@mui/icons-material/ScatterPlot';


function ImageSegment() {
    const [classification, setClassification] = useState(null);
    const formData = new FormData();

    useEffect(() => {
        // Create a timeout that will be executed after 4 seconds
        const timeoutId = setTimeout(() => {
            fetch('http://localhost:3100/upload', {
                method: 'POST',
                body: formData,
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        fetch(data.jsonUrl)
                            .then(response => response.json())
                            .then(data => {
                                console.log(data.Flag); // Print the extracted value
                                setClassification(data.Flag);
                            })
                            .catch(error => {
                                console.log('Error:', error);
                            });
                    }
                });
        }, 8000); // 4000ms equals to 4 seconds

        // Clear the timeout when the component is unmounted or the dependency changes
        return () => clearTimeout(timeoutId);
    }, []);
//     const [classification, setClassification] = useState(null);
//     const formData = new FormData();

//     useEffect(() => {
//         fetch('http://localhost:3100/upload', {
//             method: 'POST',
//             body: formData,
//         })
//             .then(response => response.json())
//             .then(data => {
//                 if (data.success) {
//                     fetch(data.jsonUrl)
//                         .then(response => response.json())
//                         .then(data => {
//                             console.log(data.Flag); // Print the extracted value
//                             setClassification(data.Flag);
//                         })
//                         .catch(error => {
//                             console.log('Error:', error);
//                         });
//                 }
//             });
//     }, []);

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <Typography variant="h4" component="h2" gutterBottom>
                Mammogram Classification
            </Typography>
            { (classification === 'Benign' || classification === 'Malignant') && (
            <Accordion
                style={{
                    backgroundColor: '#f0f0f0',
                    boxShadow: '1px 1px 5px rgba(0, 0, 0, 0.1)',
                    width: '70%',
                    marginTop: '20px',
                }}
            >
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon style={{ color: '#3f51b5' }} />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                >
                    <Typography style={{ fontWeight: 'bold' }}>Classification Result</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography>{classification ? classification : 'Loading...'}</Typography>
                </AccordionDetails>
            </Accordion>
            )}
            {classification === 'Benign' && (
                <Accordion
                    style={{
                        backgroundColor: '#f0f0f0',
                        boxShadow: '1px 1px 5px rgba(0, 0, 0, 0.1)',
                        width: '70%',
                        marginTop: '20px',
                    }}
                >
                    <AccordionSummary
                        expandIcon={<ExpandMoreIcon style={{ color: '#3f51b5' }} />}
                        aria-controls="panel1b-content"
                        id="panel1b-header"
                    >
                        <Typography style={{ fontWeight: 'bold' }}>Classification Explanation</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <List>
                            <ListItem>
                                <ListItemIcon>
                                    <BorderOuterIcon  />
                                </ListItemIcon>
                                <ListItemText
                                    primary="Well-Defined Borders"
                                    secondary="The edges of the tumor are clear and regular, making it easier to distinguish."
                                />
                            </ListItem>
                            <ListItem>
                                <ListItemIcon>
                                    <AllOutIcon  />
                                </ListItemIcon>
                                <ListItemText
                                    primary="Round or Oval Shape"
                                    secondary="The shape of a benign tumor is usually round or oval."
                                />
                            </ListItem>
                            <ListItem>
                                <ListItemIcon>
                                    <BlurOnIcon  />
                                </ListItemIcon>
                                <ListItemText
                                    primary="Uniform Density"
                                    secondary="The tissue within the tumor appears consistent throughout."
                                />
                            </ListItem>
                            <ListItem>
                                <ListItemIcon>
                                    <ScatterPlotIcon   />
                                </ListItemIcon>
                                <ListItemText
                                    primary="Macrocalcifications"
                                    secondary="Calcifications appear as large, distinct white spots."
                                />
                            </ListItem>
                        </List>
                    </AccordionDetails>
                </Accordion>
            )}
            {classification === 'Malignant' && (
                <Accordion
                    style={{
                        backgroundColor: '#f0f0f0',
                        boxShadow: '1px 1px 5px rgba(0, 0, 0, 0.1)',
                        width: '70%',
                        marginTop: '20px',
                    }}
                >
                    <AccordionSummary
                        expandIcon={<ExpandMoreIcon style={{ color: '#3f51b5' }} />}
                        aria-controls="panel1b-content"
                        id="panel1b-header"
                    >
                        <Typography style={{ fontWeight: 'bold' }}>Classification Explanation</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <List>
                            <ListItem>
                                <ListItemIcon>
                                    <BorderClearIcon  />
                                </ListItemIcon>
                                <ListItemText
                                    primary="Irregular Borders"
                                    secondary="The edges of the tumor are jagged or blurred, making it difficult to distinguish."
                                />
                            </ListItem>
                            <ListItem>
                                <ListItemIcon>
                                    <AllOutIcon />
                                </ListItemIcon>
                                <ListItemText
                                    primary="Irregular Shape"
                                    secondary="Malignant tumors tend to have irregular shapes, often described as star-like or speculated."
                                />
                            </ListItem>
                            <ListItem>
                                <ListItemIcon>
                                    <BlurOnIcon />
                                </ListItemIcon>
                                <ListItemText
                                    primary="Heterogeneous Density"
                                    secondary="The tissue within the tumor varies in appearance (mixture of light and dark areas)."
                                />
                            </ListItem>
                            <ListItem>
                                <ListItemIcon>
                                    <ScatterPlotIcon  />
                                </ListItemIcon>
                                <ListItemText
                                    primary="Macrocalcifications"
                                    secondary="Calcifications appear as tiny white specks, clusters or with irregular patterns."
                                />
                            </ListItem>
                        </List>
                    </AccordionDetails>
                </Accordion>
            )}
        </Box>
    );
}

export default ImageSegment;