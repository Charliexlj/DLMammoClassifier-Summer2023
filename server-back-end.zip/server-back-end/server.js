const express = require('express');
const multer = require('multer');
const { PythonShell } = require('python-shell');
const cors = require('cors');
const path = require('path');
const app = express();

app.use(cors());
app.use(express.static('uploads'));

const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb) {
        cb(null, 'original_mammogram' + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        const filetypes = /jpeg|jpg|png/;
        const mimetype = filetypes.test(file.mimetype);
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        if (mimetype && extname) {
            return cb(null, true);
        }
        cb("Error: File upload only supports the following filetypes - " + filetypes);
    }
});

//single image
// app.post('/upload', upload.single('image'), (req, res) => {
//     const scriptPath = 'demo.py';
    
//     PythonShell.run(scriptPath, null, function (err) {
//         if (err) {
//             console.log(err);
//             res.json({ success: false, message: err });
//             throw err;
//         }
//         console.log('Script executed successfully');
//     });
//     setTimeout(() => {
//         res.json({ success: true, url: 'http://localhost:3100/segment_mammogram.jpg' });
//     }, 4000);
//     // res.status(200).send({
//     //     success: true,
//     //     url: 'http://localhost:3100/segment_mammogram.jpg'
//     // });
// });

app.post('/upload', upload.fields([
    { name: 'image', maxCount: 1 },
    { name: 'json', maxCount: 1 }
]), (req, res) => {
    const scriptPath = 'demo.py';

    PythonShell.run(scriptPath, null, function (err) {
        if (err) {
            console.log(err);
            res.json({ success: false, message: err });
            throw err;
        }
        console.log('Script executed successfully');
    });

    setTimeout(() => {
        res.json({
            success: true,
            url: 'http://localhost:3100/segment_mammogram.jpg',
            jsonUrl: 'http://localhost:3100/FLag.json'
        });
    }, 4000);
});


app.listen(3100, () => {
    console.log('Server is running on port 3100');
});




// const express = require('express');
// const multer = require('multer');
// const { PythonShell } = require('python-shell');
// const app = express();

// const upload = multer({ dest: 'uploads/' });

// app.post('/upload', upload.single('image'), (req, res) => {
//     const scriptPath = 'demo.py';

//   PythonShell.run(scriptPath, null, function (err) {
//     if (err) {
//       res.json({ success: false });
//       console.log(err);
//       throw err;
//     }
//     console.log('Script executed successfully');
//     res.json({ success: true });
//   });
// });

// app.listen(3100, () => {
//   console.log('Server is running on port 3100');
// });


// const express = require('express');
// const multer = require('multer');
// const path = require('path');
// const cors = require('cors');

// const app = express();

// app.use(cors());

// const storage = multer.diskStorage({
//     destination: function(req, file, cb) {
//         cb(null, 'uploads/')
//     },
//     filename: function(req, file, cb) {
//         cb(null, 'original_mammogram' + path.extname(file.originalname))
//     }
// });

// const upload = multer({
//     storage: storage,
//     fileFilter: (req, file, cb) => {
//         const filetypes = /jpeg|jpg|png/;
//         const mimetype = filetypes.test(file.mimetype);
//         const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
//         if (mimetype && extname) {
//             return cb(null, true);
//         }
//         cb("Error: File upload only supports the following filetypes - " + filetypes);
//     }
// });

// app.post('/upload', upload.single('image'), (req, res) => {
//     res.json({file: req.file});
// });

// app.listen(3100, () => console.log('Server started on port 3100'));

